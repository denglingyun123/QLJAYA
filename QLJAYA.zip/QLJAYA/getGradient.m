function [g,count,curve] = getGradient(x0, f,count,curve,GBestF)
    g = zeros(size(x0));
    fx0 = f(x0);
    count=count+1;
    curve(count)=GBestF;
%     step=(1e-6)*(up-low);
    step = 1e-5;
    
    for i = 1 : length(x0)
        xli = x0;
        xli(i) = x0(i) + step;
        g(i) = ( f(xli) - fx0 ) / step;
    end
end