function G = truncGrad(G,GRADMAX,dim)

%% Gradient
    for j=1:dim
        if G(j)<-GRADMAX(j)
            G(j)=-GRADMAX(j);
        end
        if G(j)>GRADMAX(j)
            G(j)=GRADMAX(j);
        end
    end
%     iddown = G < -GRADMAX;
%     idup = G > GRADMAX;
% 
%     G(iddown) = -GRADMAX;
%     G(idup) = GRADMAX; 
end