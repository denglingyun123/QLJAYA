
function [GBestX,GBestF,curve]=QLJAYA(pop,Max_count,lb,ub,dim,fobj)
% tic
if(max(size(ub)) == 1)
   ub = ub.*ones(1,dim);
   lb = lb.*ones(1,dim);  
end

%Initialization
X0=initialization_SSA(pop,dim,ub,lb);
X = X0;
count=0; %Record the number of function evaluations

%Fitness evaluation
fitness = zeros(1,pop);
for i = 1:pop
   fitness(i) =  fobj(X(i,:));
   count=count+1;
end

[fitness, index]= sort(fitness);%Sorting
GBestF = fitness(1);%Current best fitness

%According to the fitness sorting,X(1,:) represents the current best
%position and X(end,:)is the current worst position
for i = 1:pop
    X(i,:) = X0(index(i),:);
end

GBestX = X(1,:);%Current best position
curve(1:pop)=GBestF;
X_new = X;

uCR=0.5;%��ʼ���������
uF=0.5;%��ʼ����������

%initialize reward table
state_num=2;action_num=2;
Reward_table=[
    -1 +1 
    +1 +1];
Q_table=zeros(state_num,action_num);
cur_state=1;  %the fittest state
episode=100;
gamma=0.8;
Max_iter=Max_count/pop;

% Initialize the probabilistic model
sigma=0.1*ones(1,pop);
Gradient_MAX=(ub-lb)/2;
beta=ones(1,pop); %Intilize controlling factor

l=20;
rate=0.6;
num_elite=pop*rate;
A=X(1:num_elite,:);

% Main loop
t=2;
while count<=Max_count
    
    GBestX = X(1,:);
    Psecond=X(2,:);
    Pworst = X(end,:);
    
    Scr=[];%��ʼ�ɹ��μӱ���ĸ���Ľ������Ϊ�ռ�-------��ʼ���������Ϊ�ռ�
    Sf=[];%��ʼ�ɹ��μӱ���ĸ������������Ϊ�ռ�---------��ʼ���������Ϊ�ռ�
    n1=1;%��¼Scr�е�Ԫ�ظ���----
    n2=1;%��¼Sf�е�Ԫ�ظ���-----
    RB=randn(pop,dim);
   %% A modified position updating stage of RLJAYA algorithm
   for i = 1:pop
       flag=zeros(1,pop);
       
       if(Q_table(cur_state, 1) >= Q_table(cur_state, 2))
           action_num=1;
%        if rand<beta(i)
           X_new(i,:) = X(i,:) + (rand(1,dim).*(X(1,:) - X(i,:)) - rand(1,dim).*(Pworst - X(i,:)));
       else
           action_num=2;
           [Gradient_X(i,:),count,curve]=getGradient(X(i,:),fobj,count,curve,GBestF);
           if count>=Max_count
%                toc
%                disp(['The runtime of QLJAYA: ',num2str(toc)]);
               return;
           end
           
           Gradient_X(i,:)=truncGrad(Gradient_X(i,:),Gradient_MAX,dim); % trunc gradient
           
           X1=X(i,:)-sigma(i)*1.8*Gradient_X(i,:);
           f1=fobj(X1);
           count=count+1;
           curve(count)=GBestF;
           if count>=Max_count
%                toc
%                disp(['The runtime of QLJAYA: ',num2str(toc)]);
               return;
           end
           
           X2=X(i,:)-(sigma(i)/1.8)*Gradient_X(i,:);
           f2=fobj(X2);
           count=count+1;
           curve(count)=GBestF;
           if count>=Max_count
%                toc
%                disp(['The runtime of QLJAYA: ',num2str(toc)]);
               return;
           end
           
           if f1<=f2
               sigma(i)=sigma(i)*1.8;
           else
               sigma(i)=sigma(i)/1.8;
           end
  
           X_new(i,:)=X(i,:)-sigma(i)*Gradient_X(i,:);
       end
   end
    
   % Bound control
   for i = 1:pop
       for a = 1: dim
           if(X_new(i,a)>ub(a))
               X_new(i,a) =ub(a);
           end
           if(X_new(i,a)<lb(a))
               X_new(i,a) =lb(a);
           end
       end
   end
   
   %Greedy selection
   for i=1:pop
       fitness_new(i) = fobj(X_new(i,:));
       count=count+1;
       
       if fitness_new(i)<fitness(i)
           Reward_table(cur_state, action_num )=+1;
           X(i,:) = X_new(i,:);
           fitness(i) = fitness_new(i);
%            flag(i)=flag(i)-1;
       else
           Reward_table(cur_state, action_num )=-1;
       end 
        
       if(fitness_new(i) < GBestF)
           GBestF = fitness_new(i);
           GBestX = X_new(i,:);   
       end
       
       cur_state=action_num;
       
        %-------------------Update Q-table
        times=0;  
        current_state=randperm(state_num,1);
        for k=1:episode
            
            %randomly choose an action from current state
            while isempty(find(Reward_table(current_state,:)>-1))
                current_state=rem(current_state,2)+1;
            end
            
            %Choose the best action from the current state from Q-Table
            optional_action=find(Reward_table(current_state,:)>-1);  
            
            %Execute action 
            chosen_action=optional_action(randperm(length(optional_action),1));
            
            %get current reward
            r=Reward_table(current_state,chosen_action);  
            
            %Find out the new state
            next_state=chosen_action;  
            times=times+1;
            
            %Acquire the corresponding maximum Q-value 
            if isempty(find(Reward_table(next_state,:)>-1))
                next_state=rem(next_state,2)+1;
            end
            
            next_possible_action=find(Reward_table(next_state,:)>-1);
            maxQ=max(Q_table(next_state,next_possible_action));  
            
            %update the Q-values Table matrix by Bellman Equation
            studyrate=1-(0.9*t/Max_iter);
            Q_table(current_state,chosen_action) = Q_table(current_state,chosen_action)+studyrate*(r+gamma * maxQ -Q_table(current_state,chosen_action)); %Bellman����
            
            %Update the current state,s(t)=s(t+1) 
            current_state=next_state; 
        end
       
       curve(count)=GBestF;
       if count>=Max_count
%            toc
%            disp(['The runtime of QLJAYA: ',num2str(toc)]);
           return;
       end
   end
   
   [fitness, index]= sort(fitness);%Sorting
   X = X(index,:);
   
   %% Covariance matrix learning
   C=Archive_matrix(X,A,t,l,num_elite);
   [Q,~]=eig(cov(C));
   X_temp = X*Q;
   for i=1:pop
       CR(i)=normrnd(uCR,0.1);%������̬�ֲ�-----��Ⱥ��Ӧ��ÿһ���������
       F(i)=cauchyrnd(uF,0.1);%���ӿ����ֲ�-----��Ⱥ��Ӧ��ÿһ���������
       while (CR(i)>1||CR(i)<0)
           CR(i)=normrnd(uCR,0.1);  %��ֹCRԽ��
       end
       while(F(i)<=0)
           F(i)=cauchyrnd(uF,0.1);
       end
       if (F(i)>1)                   %��ֹFԽ��
           F(i)=1;
       end
       
       r = generateR(pop,i);
       jrand=randi([1,dim]); 
       for j=1:dim
           if (rand<=CR(i)||j==jrand)
%                F=rand;
              X_new1(i,j) = X_temp(r(1),j) + F(i)*(X_temp(r(2),j)-X_temp(r(3),j)); % DE/rand/1
           else
%               F = rand;
              X_new1(i,j)=X_temp(i,j)+F(i)*(X_temp(r(1),j)-X_temp(i,j))+F(i)*(X_temp(r(2),j)-X_temp(r(3),j)); %DE/current-to-rand/1
%                X_new1(i,j)=RB(i,j)*X_temp(i,j);
           end
       end
       X_new1(i,:)=X_new1(i,:)*Q';
   end
   
   % Bound control
   for i = 1:pop
       for a = 1: dim
           if(X_new1(i,a)>ub(a))
               X_new1(i,a) =ub(a);
           end
           if(X_new1(i,a)<lb(a))
               X_new1(i,a) =lb(a);
           end
       end
   end
   
   %Greedy selection
   for i=1:pop
       fitness_new1(i) = fobj(X_new1(i,:));
       count=count+1;
       
       if fitness_new1(i)<fitness(i)
           X(i,:) = X_new1(i,:);
           fitness(i) = fitness_new1(i);
           Scr(n1)=CR(i);
           Sf(n2)=F(i);
           n1=n1+1;
           n2=n2+1;
           
%            flag(i)=flag(i)-1;
       end 
       
%        beta(i)=beta(i)*(1+0.01*(flag(i)));
%         if beta(i)>=1
%             beta(i)=1;
%         end
        
       if(fitness_new1(i) < GBestF)
           GBestF = fitness_new1(i);
           GBestX = X_new1(i,:);   
       end
       
       %����Ӧ����������uCR��uF-------��������Ӧ�����Ŀ���
        c=0.1;
        [~,ab]=size(Scr);
        if ab~=0
            newSf=(sum(Sf.^2))/(sum(Sf));
            uCR=(1-c)*uCR+c.*mean(Scr);
            uF=(1-c)*uF+c.*newSf;
        end
       
       curve(count)=GBestF;
       if count>=Max_count
%            toc
%            disp(['The runtime of QLJAYA: ',num2str(toc)]);
           return;
       end
   end

    
   [fitness, index]= sort(fitness);%Sorting
   X = X(index,:);
   
  
   GBestF=fitness(1);
   GBestX=X(1,:);   
   t=t+1;
   
end

end



